import React from 'react';
import { Star, MessageCircle, Instagram, Facebook, RefreshCw } from 'lucide-react';
import { CAFE_DATA } from '../types';

interface SocialProofProps {
  rating: number;
  reviewCount: number;
  isSyncing: boolean;
  lastSynced: string | null;
}

export const SocialProof: React.FC<SocialProofProps> = ({ rating, reviewCount, isSyncing, lastSynced }) => {
  return (
    <section className="py-20 bg-cafe-black text-white relative overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-7xl font-display font-bold mb-4">
            ČÍSLA <span className="text-cafe-accent">NELŽOU.</span>
          </h2>
          <p className="text-xl text-stone-400">Pokaždé, když někdo napíše recenzi na Google, uvidíte to i tady.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {/* Card 1 - Rating */}
          <div className="group bg-stone-900/50 border border-stone-800 p-8 rounded-3xl text-center hover:bg-stone-800 transition-all hover:-translate-y-1">
            <Star className="w-12 h-12 text-yellow-400 mx-auto mb-4 fill-yellow-400 group-hover:scale-110 transition-transform" />
            <div className="text-6xl font-display font-bold mb-2 flex items-center justify-center">
              {rating.toFixed(1)}
              <span className="text-2xl text-stone-600 ml-1">/5</span>
            </div>
            <div className="text-stone-400 uppercase tracking-widest font-bold text-sm">Průměrné hodnocení</div>
          </div>

          {/* Card 2 - Reviews */}
          <div className="group bg-stone-900/50 border border-stone-800 p-8 rounded-3xl text-center hover:bg-stone-800 transition-all hover:-translate-y-1">
            <MessageCircle className="w-12 h-12 text-cafe-accent mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <div className="text-6xl font-display font-bold mb-2">
              {reviewCount.toLocaleString('cs-CZ')}
            </div>
            <div className="text-stone-400 uppercase tracking-widest font-bold text-sm">Ověřených recenzí</div>
          </div>

          {/* Card 3 - Instagram */}
          <a 
            href={CAFE_DATA.instagramLink}
            target="_blank"
            rel="noreferrer"
            className="group bg-gradient-to-br from-purple-900/50 to-pink-900/50 border border-stone-800 p-8 rounded-3xl text-center hover:border-pink-500/50 transition-all relative overflow-hidden hover:-translate-y-1"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative z-10">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full p-1 bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 group-hover:scale-105 transition-transform">
                 <img 
                  src="https://unavatar.io/instagram/cafevsehochut" 
                  alt="Instagram Profile" 
                  className="w-full h-full rounded-full border-2 border-black"
                />
              </div>
              <div className="text-2xl font-display font-bold mb-2 flex items-center justify-center gap-2">
                 <Instagram className="w-6 h-6" />
                 Instagram
              </div>
              <div className="text-stone-300 text-sm group-hover:text-white transition-colors">
                @cafevsehochut
              </div>
            </div>
          </a>

          {/* Card 4 - Facebook */}
          <a 
            href={CAFE_DATA.facebookLink}
            target="_blank"
            rel="noreferrer"
            className="group bg-gradient-to-br from-blue-900/50 to-indigo-900/50 border border-stone-800 p-8 rounded-3xl text-center hover:border-blue-500/50 transition-all relative overflow-hidden hover:-translate-y-1"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative z-10">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full p-1 bg-gradient-to-tr from-blue-400 to-blue-600 group-hover:scale-105 transition-transform">
                 <div className="w-full h-full rounded-full border-2 border-black bg-blue-600 flex items-center justify-center">
                    <Facebook className="w-10 h-10 text-white fill-white" />
                 </div>
              </div>
              <div className="text-2xl font-display font-bold mb-2 flex items-center justify-center gap-2">
                 <Facebook className="w-6 h-6" />
                 Facebook
              </div>
              <div className="text-stone-300 text-sm group-hover:text-white transition-colors">
                Café Všehochuť
              </div>
            </div>
          </a>
        </div>

        {/* Reviews Section */}
        <div className="bg-white text-cafe-black rounded-[2rem] p-8 md:p-12 max-w-4xl mx-auto transform rotate-1 shadow-2xl">
          <h3 className="text-3xl font-display font-bold mb-8 text-center">
            Aktuální zpětná vazba:
          </h3>
          
          <div className="space-y-6">
            <div className="flex items-start gap-4 p-4 bg-stone-50 rounded-xl border border-stone-100">
              <div className="bg-green-100 p-2 rounded-full text-green-700 font-bold text-[10px] tracking-tighter uppercase whitespace-nowrap">TOP RECENZE</div>
              <div>
                <div className="flex text-yellow-500 mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="font-medium text-lg italic">"Skvělá atmosféra a obsluha pokaždé. V Jičíně jasná volba."</p>
                <p className="text-sm text-stone-400 mt-1">- Místní průvodce Google</p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-stone-50 rounded-xl border border-stone-100">
               <div className="bg-green-100 p-2 rounded-full text-green-700 font-bold text-[10px] tracking-tighter uppercase whitespace-nowrap">TOP RECENZE</div>
              <div>
                <div className="flex text-yellow-500 mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="font-medium text-lg italic">"Nejlepší místo na relax v Jičíně. Kafe je prostě top."</p>
                <p className="text-sm text-stone-400 mt-1">- Ověřený návštěvník</p>
              </div>
            </div>
            
            <div className="text-center pt-4">
              <a href={CAFE_DATA.googleMapsLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-cafe-accent font-bold hover:text-cafe-black transition-colors text-lg">
                Zobrazit všech {reviewCount} recenzí na Google Maps
                <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};